def main() -> None:
    print("Hello from mg1640-local-document-assistant!")
